package connection;

import java.sql.Connection;
import java.sql.SQLException;

public class TesteConexao {
    /*public static void main(String[] args) throws SQLException {Connection connection = new ConnectionDB().getConnection();
       System.out.println("Deu certo!");
       connection.close();

    }*/
}
