# CRUD-Java
A simple crud in Java.
